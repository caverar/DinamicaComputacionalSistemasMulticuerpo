# Simulación Computacional de Sistema Multicuerpo sobre mecanismo de 3 barras

Instalación de dependencias

``` sh
pip install -r requirements.txt
```
